// Estrutura básica de uma API RESTful com Node.js e Express

const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const db = require('./db');

const app = express();
const port = 3000;

let movies = [];

function loadMovies() {
    fs.createReadStream('Movielist.csv')
        .pipe(csv({ separator:";" }))
        .on('data', (row) => {
            db.run(
                `insert into movies (title, year, producers, winner) values (?, ?, ?, ?)`,
                [row['title'], parseInt(row['year']), row['producers'], row['winner'] === 'yes']
            );
        })
        .on('end', () => {
            console.log('CSV carregado no banco de dados!');
        });
}

loadMovies();

app.get('/awards/intervals', (req, res) => {    
    db.all(`select * from movies where winner = 1`, [], (err, rows) => {
        console.log(rows);
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }

        let producerWins = {};
        rows.forEach(movie => {
            const producers = movie.producers.split(',').map(p => p.trim());
            producers.forEach(producer => {
                if (!producerWins[producer]) producerWins[producer] = [];
                producerWins[producer].push(movie.year);
            });
        });

        let intervals = [];
        for (const producer in producerWins) {
            let years = producerWins[producer].sort((a, b) => a - b);
            for (let i = 1; i < years.length; i++) {
                intervals.push({
                    producer,
                    interval: years[i] - years[i - 1],
                    previousWin: years[i - 1],
                    followingWin: years[i]
                });
            }
        }

        const minInterval = Math.min(...intervals.map(i => i.interval));
        const maxInterval = Math.max(...intervals.map(i => i.interval));

        res.json({
            min: intervals.filter(i => i.interval === minInterval),
            max: intervals.filter(i => i.interval === maxInterval)
        });
    });
});

app.listen(port, () => {
    console.log(`API rodando em http://localhost:${port}`);
});

/*
// Testes de integração com Jest
const request = require('supertest');

describe('GET /awards/intervals', () => {
    it('deve retornar os intervalos de prêmios corretamente', async () => {
        const response = await request(app).get('/awards/intervals');
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('min');
        expect(response.body).toHaveProperty('max');
    });
});
*/